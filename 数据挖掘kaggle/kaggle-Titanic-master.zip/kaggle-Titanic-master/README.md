# kaggle-Titanic
python 2.7
scikit learn 0.15
numpy && scipy && matplotlib

Titanic is a competition in Kaggle for knowledge. 
For detail infomation: http://www.cnblogs.com/north-north/p/4360121.html
